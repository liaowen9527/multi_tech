# GDI textview
Test task: simple gdi MVC implementation to view unicode text file
