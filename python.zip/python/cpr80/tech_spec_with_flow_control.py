# url parameter looks like https://192.168.30.11:17778/web_api/login
# usr: admin
# pwd: *****
import copy
import re
import json
import base64
import itertools
import requests
import threading
import traceback
import time
import uuid

import sys

sys.path.append("C:\\Source\\ng\\Backend\\resource\\nb_python")
sys.path.append("C:\\Source\\ng\\Backend\\resource\\nb_python\\netbrain\\techspec\\common")

from datetime import datetime
from netbrain.common.models import NCTStatus, NCTTable
from SimpleCache import SimpleCache

is_worker_side = False
is_fs_side = False
g_http_timeout = 300
try:
    import CDBHelper
    import pythonlib

    is_worker_side = True
    is_fs_side = False
except ImportError:
    is_worker_side = False
    is_fs_side = True

try:
    requests.packages.urllib3.disable_warnings()
except Exception as e:
    print(str(e))

_debug = True
_nct_details = False
_use_cache = True
_use_api_discovery = False
time.sleep(5)


def dpt(*args, **kwargs):
    if _debug:
        str_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        tid = int(threading.current_thread().ident)
        log = str(args, **kwargs)
        print("%s [TID:%d] %s" % (str_date, tid, log))
        # print(*args, **kwargs)


class Device:
    def __init__(self, uid):
        self.id = uid
		

class StatLog(dict):
    '''
        cache = SimpleCache.getInstance()
        cache.get('key')
        cache.set('key', 'value')
    '''
    __singleton_lock = threading.Lock()
    def __new__(cls, *args):
        if not hasattr(cls, '_instance'):
            cls._instance = dict.__new__(cls)
        else:
            #raise Exception('SimpleCache already initialized')
            pass
        return cls._instance

    @classmethod
    def getInstance(cls):
        if not hasattr(cls, '_instance'):
            with cls.__singleton_lock:
                if not hasattr(cls, '_instance'):
                    cls._instance = dict.__new__(cls)
        return cls._instance

    def get(self, name, default=None):
        with StatLog.__singleton_lock:
            if not name: return default
            if name not in self: return default
            value = self[name]
            if value.get('time', None) and value.get('ttl', None):
                if (int)(time.time() - value['time']) >= value['ttl']:
                    del self[name]
                    return default
            return value

    def set(self, name, value):
        with StatLog.__singleton_lock:
            self[name] = value

    def getset(self, name, value):
        with StatLog.__singleton_lock:
            g = self.get(name)
            if not g:
                g = value
                self.set(name, g)
            return g
    def requestEntry(self,value):
        tid = str(threading.current_thread().ident)
        taskValue = self.get(tid)
        if not taskValue:
            return
        requestId = str(uuid.uuid4())
        taskValue['active'] = requestId
        value['startTime'] = time.time()
        taskrequests = taskValue.get('requests') or {}
        taskrequests[requestId] = value
        taskValue['requests'] = taskrequests
    def requestExist(self):
        tid = str(threading.current_thread().ident)
        taskValue = self.get(tid)
        if not taskValue:
            return
        taskrequests = taskValue.get('requests')
        if not taskrequests:
            return
        requestId = taskValue.get('active')
        now = time.time()
        value = taskrequests.get(requestId)
        startTime = value.get('startTime')
        value['endTime'] = now
        value['duration'] = now - startTime
        taskrequests[requestId] = value
        taskValue['requests'] = taskrequests

    def taskEntry(self,value):
        value['startTime'] = time.time()
        self.set(str(threading.current_thread().ident),value)
    def taskExit(self):
        tid = str(threading.current_thread().ident)
        value = self.get(tid)
        if not value:
            return
        startTime= value.get('startTime')
        now = time.time()
        if(startTime):
            duration = now - startTime
        value['endTime'] = now
        value['duration'] = duration
        self.printSummary()
        self.printDetail(value)
        self.pop(tid)
    def printSummary(self):
        sum = len(self)
        dpt("Statistic log: Current thread number: %s" % sum)
    def printDetail(self,value):
        dpt("Statistic log: Task finished: %s" % json.dumps(value))


class NBRequest:
    def __init__(self, endpoint, url, header, body):
        self.endpoint = endpoint
        self.url = url
        self.header = header
        self.body = body
        self.timeout = 600
        self.proxies = {}
        self.can_merge = True

        self.regist_time = None
        self.begin_time = None
        self.end_time = None

    def equal(self, right):
        return self.endpoint == right.endpoint \
            and self.url == right.url \
            and self.header == right.header \
            and self.body == right.body \
            and self.proxies == right.proxies 

class WaitStatus:
    def __init__(self):
        self.dup = None
        self.not_found = False
        self.wait_again = False

class NbMergeItem:
        def __init__(self):
            self.items = []
            self.resp = None

class NbMergeRequst:
    def __init__(self):
        self.category = {}

    def regist(self, req):
        if None == self.category.get(req):
            self.category[req] = NbMergeItem()

    def add_item(self, key, req):
        item = self.get_item(key)
        if None == item:
            return False
        
        item.items.append(req)
        return True

    def remove_item(self, key, req):
        item = self.get_item(key)
        if None == item:
            return False
        
        if key != req:
            item.items.remove(req)

        if len(item.items) == 0:
            self.category.pop(key)

        return True

    def get_item(self, key):
        return self.category.get(key)

    def get_resp(self, key):
        item = self.get_item(key)
        if None == item:
            return None

        return item.resp

    def set_resp(self, key, resp):
        item = self.get_item(key)
        if None == item:
            return False

        item.resp = resp
        return True

class NbResponse:
    def __init__(self):
        self.req = None
        self.req_real = None
        self.resp = None


class NbRequestMgr:
    def __init__(self):
        self.lock = threading.Lock()
        self.req_buffer = []
        self.req_running = {}
        self.req_merge = NbMergeRequst()

        self.utc_time = True
        self.max_request = 10
        self.req_index = {}

    def post(self, req):
        result = self.post_once(req)

        if req.can_merge and result.resp == None and result.req != result.req_real:
            dpt("post again req: %d" % (req.index))
            req.can_merge = False
            result = self.post_once(req)

        return result.resp
    
    def post_once(self, req):
        self.regist(req)
        dpt("begin req: %d" % (req.index))

        result = self.do_post(req)

        dpt("end req: %d" % (req.index))
        self.unregist(result.req, result.req_real, result.resp)
        return result

    def do_post(self, req):
        result = NbResponse()
        result.req = req
        result.req_real = req

        status = self.wait_access(req)
        if status.dup:
            result.req_real = status.dup
            result.resp = self.wait_response(status.dup)
            if result.resp is not None:
                dpt("get resp by merge request: %s, index: %d, merge_index:%d" 
                    % (req.endpoint, req.index, status.dup.index))
                
        else:
            result.resp = self.http_post(req)
            
        return result

    def http_post(self, req):
        dpt("execute endpoint: %s, index: %d" % (req.endpoint, req.index))
        resp = None
        try:
            req.begin_time = self.get_current_time()
            resp = requests.post(req.url,
                headers=req.header,
                data=req.body,
                proxies=req.proxies,
                verify=False,
                timeout=req.timeout)

        except Exception as e:
            dpt(e)
            dpt(traceback.format_exc())
            dpt(req.url)

        return resp

    def wait_response(self, req):
        while True:
            with self.lock:
                if None == self.req_running.get(req.endpoint):
                    return None

                arr = self.req_running.get(req.endpoint)
                if req not in arr:
                    return self.req_merge.get_resp(req)

            time.sleep(0.1)
            
        return None

    def cancel(self, req):
        pass

    def regist(self, req):
        with self.lock:
            #category request by endpoint
            if None == self.req_index.get(req.endpoint):
                self.req_index[req.endpoint] = 1
            req.index = self.req_index[req.endpoint]
            self.req_index[req.endpoint] = req.index + 1

            req.regist_time = self.get_current_time()
            self.req_buffer.append(req)

    def unregist(self, req, real_req, resp):
        req.end_time = self.get_current_time()
        with self.lock:
            if req in self.req_buffer:
                self.req_buffer.remove(req)
            else:
                #remove from running request
                arr = self.req_running.get(req.endpoint)
                if arr and req in arr:
                    arr.remove(req)
                    #record result, for merge items
                    self.req_merge.set_resp(req, resp)
                    dpt("unregist endpoint: %s, index: %d" % (req.endpoint, req.index))
            
            self.req_merge.remove_item(real_req, req)

    def wait_access_once(self, req):
        status = WaitStatus()
        with self.lock:
            if req not in self.req_buffer:
                status.not_found = True
                return status

            if None == self.req_running.get(req.endpoint):
                self.req_running[req.endpoint] = []
            
            arr = self.req_running.get(req.endpoint)

            #check if has same request is running
            same_req = None
            if req.can_merge:
                for temp in arr:
                    if req.equal(temp):
                        same_req = temp
                        break
            #
            if same_req:
                #the same_req is running now
                self.req_merge.add_item(same_req, req)
                status.dup = same_req
                #move from buffer queue, avoid block other request
                self.req_buffer.remove(req)
                return status
            else:
                if len(arr) < self.max_request:
                    #must at the front of queue
                    first = self.req_buffer[0]
                    if first == req:
                        #move to running list
                        self.req_buffer.remove(req)
                        arr.append(req)
                        #regist a merge category
                        self.req_merge.regist(req)

                        return status
        
        status.wait_again = True
        return status


    def wait_access(self, req):
        while True:
            status = self.wait_access_once(req)
            if not status.wait_again:
                return status

            time.sleep(0.1)


    def get_current_time(self):
        if self.utc_time:
            return datetime.utcnow().isoformat()

        return datetime.now().isoformat()



class Locks:
    __instance = None
    __lock = threading.Lock()

    @staticmethod
    def getInstance():
        """ Static access method. """
        instance = Locks.__instance
        if instance is None:
            Locks.__lock.acquire()
            instance = Locks.__instance
            if instance is None:
                Locks.__instance = instance = Locks()
        return instance

    def __init__(self):
        """ Virtually private constructor. """
        if Locks.__instance is not None:
            raise Exception("This class is a singleton!")
        else:
            Locks.__instance = self
            self.endpoint2locks = {}
            self.lock = threading.Lock()
            self.nbRequestMgr = NbRequestMgr()

    def update_lock(self, endpoint):
        self.lock.acquire()
        if endpoint not in self.endpoint2locks:
            self.endpoint2locks[endpoint] = threading.Lock()
        self.lock.release()

    def request_access(self, endpoint):
        lock = self.endpoint2locks[endpoint]
        lock.acquire()
        time.sleep(1)

    def release_lock(self, endpoint):
        lock = self.endpoint2locks[endpoint]
        lock.release()


class APIPlugin:
    def __init__(self, user, pwd, url, params=None, **kw):
        # proxy
        self._proxy_info = None
        self._proxies = {}
        # login param
        self._user = user
        self._pwd = pwd
        self._domain = ''  # domain name
        self._url = url + '/web_api/'  # url = 'https://dn'
        self._sid = ''  # session id
        self._timeout = 600  # default 600s
        self._last_login_time = time.time()
        self._api_ver = '1.1'  # default: 1.1
        if _use_cache is True:
            self._sid_cache = SimpleCache.getInstance()
            self.clear_session_cache()
        else:
            self._sid_cache = {}
        self._external_server_id = ''
        self._ap_id = ''
        self._tech_id = ''
        self.err_msg = ''
        self.status_code = 0
        self.discover_results = {'found': {30080: {}, 2007: {}}, 'log': ''}
        self._support_checkpoint_subtypes = [30080, 2007]
        self._dotscan_skip_checkpoint_subtype = []
        self._stop_by_outside = False
        self._test = kw.get('test', False)
        # extra params
        self._extra_info = None
        self._sourceId = ''
        self._sourceType = ''
        self._topoTypeIds = []
        # cache data
        self._topo_nodes = []
        self._topo_links = []
        self._topo_intfs = []
        self._query_class = []
        self._schema_real_device = {}
        self._schema_real_device_interface = []
        self._schema_real_intface = {}
        self._schema_real_device_interface_keys = []
        self._real_devices = []
        self._legacy_real_devices = {}
        self._real_device_ids = {}
        self._nct_data = {}

        # class -> [object data]

        self._discover_flag = False
        self._retrieve_option = {'basicInfo': False, 'detailInfo': False, 'topologyInfo': False}
        self._ip = self._url.rpartition('://')[2].partition('/')[0].partition(':')[0]
        if is_worker_side:
            self._external_server_id, self._ap_id, self._tech_id = CDBHelper.GetExternalServerInfo(self._ip)
        # parse param
        self._devId = ''
        self._devName = ''
        self._mgmtIP = ''
        self._snmpName = ''
        self._dn = ''
        self._instance_id = ''
        self._tenant_db_name = ''
        self._domain_db_name = ''
        self._dataSourceId = ''
        self._extraParams = None
        self._bNeedRetrieveData = False
        self._bNeedRebuildTopo = False
        if params is not None and len(params) == 8:
            self._tenant_db_name = params[1]
            self._domain_db_name = params[2]
            self._instance_id = params[3]
            proxy_param = params[4]
            # isEnabled,ip,port,username, password
            if proxy_param != "" and proxy_param != "{}":
                self._proxies = json.loads(proxy_param)
            extra_params = params[5]
            # {key:value,...}
            if extra_params != "" and extra_params != "{}":
                self._extra_info = json.loads(extra_params)

            self._bNeedRetrieveData = bool(params[6])
            self._bNeedRebuildTopo = bool(params[7])
        if params:
            param = params
            if isinstance(param, str):
                param = json.loads(param)
            if 'devId' in param:
                self._devId = param['devId']
            if 'mgmtIP' in param:
                self._mgmtIP = param['mgmtIP']
            if 'snmpName' in param:
                self._snmpName = param['snmpName']
            if 'dn' in param:
                self._dn = param['dn']
            else:
                if 'nbPathValue' in param:
                    self._dn = param['nbPathValue']
                elif 'nbPathValues' in param:
                    for pathValue in param['nbPathValues']:
                        self._dn = pathValue
                        break
                if self._dn != '':
                    self._instance_id = self._dn.partition('/')[0]
                    self._dn = self._dn.partition('/')[2]
                else:
                    self._dn = self._devId

            if 'name' in param:
                self._devName = param['name']
            if 'tenant_db_name' in param:
                self._tenant_db_name = param['tenant_db_name']
            if 'domain_db_name' in param:
                self._domain_db_name = param['domain_db_name']
            if 'dataSourceId' in param:
                self._dataSourceId = param['dataSourceId']

            if 'apis' in param:
                apis = param['apis']
                for rootSchema in apis:
                    if rootSchema == 'CheckPointR80':
                        techParam = apis[rootSchema]
                        if 'username' in techParam:
                            self._username = techParam['username']
                        if 'password' in techParam:
                            self._password = techParam['password']
                        if 'endpoint' in techParam:
                            self._endpoint = techParam['endpoint']
                        if 'extraParams' in techParam:
                            if isinstance(techParam['extraParams'], str):
                                self._extraParams = json.loads(techParam['extraParams'])
                            else:
                                self._extraParams = techParam['extraParams']
                        break
            else:
                if 'username' in param:
                    self._username = param['username']
                if 'password' in param:
                    self._password = param['password']
                if 'endpoint' in param:
                    self._endpoint = param['endpoint']
                if 'extraParams' in param:
                    if isinstance(param['extraParams'], str):
                        self._extraParams = json.loads(param['extraParams'])
                    else:
                        self._extraParams = param['extraParams']

        # parse API param
        self._cluster_map = {}
        self._init_session()
        # time.sleep(1)

    def _init_session(self):
        self.get_session_id()
        if self._test is False:
            self.get_domain_session()

    def generate_session_key(self):
        return self.generate_sid_cache_key(self._domain, self._url,"")

    def generate_sid_cache_key(self, domain, url,body ):
        return 'Domain:%s, URL:%s, Body: %s' % (domain, url, body if body else "")

    def get_session_id(self, clear=True):
        dpt('start to get session id')
        login_url = self._url + 'login'
        login_para = self.gen_headers_and_body('login', domain=self._domain)
        cache_key = self.generate_session_key()
        try:
            if not self._sid_cache.get(cache_key):
                time.sleep(1)
                dpt('Create new sid')
                sid_resp = self.get_resp(login_url, login_para) or {}
                sid = sid_resp.get('sid')
                uid = sid_resp.get('uid')
                self._timeout = session_timeout = sid_resp.get('session-timeout')
                last_lg_tm = sid_resp.get('last-login-was-at') or {}
                if isinstance(last_lg_tm, str) and last_lg_tm.startswith('{'):
                    last_lg_tm = json.loads(last_lg_tm)
                if 'posix' in last_lg_tm:
                    self._last_login_time = last_lg_tm.get('posix')

                try:
                    self._api_ver = float(sid_resp.get('api-server-version'))
                except TypeError:
                    self._api_ver = 1.1
                if sid:
                    self._sid = sid
                    if _use_cache is True:
                        if clear:
                            self.check_timeout_session()
                        self._sid_cache.set(cache_key,
                                            {'api_type': 'CheckPointR80', 'uid': uid, 'sid': sid, 'url': self._url,
                                             'ttl': session_timeout, 'time': time.time(),
                                             'api_version': self._api_ver})
                else:
                    dpt('retrieve sid failed!')
            else:
                dpt('Use old sid')
                session_cache = self._sid_cache.get(cache_key)
                self._sid = session_cache.get('sid')
                try:
                    self._api_ver = float(session_cache.get('api_version'))
                except TypeError:
                    self._api_ver = 1.1
        except Exception:
            dpt(traceback.format_exc())

        if self._sid:
            dpt('get session id:"%s" successfully' % self._sid)
            return self._sid
        else:
            self.status_code = 999

    def get_domain_session(self):
        gw_sv_dict = self.generic_call_api_resp('show-gateways-and-servers') or []
        for gw_sv in gw_sv_dict:
            result_matched = self.check_device_matched(gw_sv)
            if not result_matched:
                continue
            domain = gw_sv.get('domain') or {}
            domain_uid = domain.get('uid')
            if domain_uid:
                self._domain = domain_uid
                self.get_session_id()
                break

    def is_sid_cache(self, body):
        return body.get('sid') 

    def clear_session_cache(self, key=None, ttl=0):
        try:
            dpt("clear_session_cache, key:%s, ttl%s" % (key, ttl))
            if key and key in self._sid_cache:
                self._sid_cache.pop(key)
                dpt("1, remove cache key:%s" % key)
                return True
            pop_pool = []
            for header, body in self._sid_cache.items():
                _type = body.get('api_type') or ''
                if _type != 'CheckPointR80':
                    continue

                if self.is_sid_cache(body):
                    continue

                _time = body.get('time')
                _ttl = ttl or body.get('ttl')
                if not (_time and _ttl):
                    continue
                #ttl unit: second;  time unit: second
                if (int)(time.time() - _time) >= _ttl:
                    dpt('clear session cache of <%s>' % header)
                    pop_pool.append(header)
            for pop_key in pop_pool:
                self._sid_cache.pop(pop_key)
                dpt("2, remove cache key:%s" % pop_key)
        except Exception:
            dpt(traceback.format_exc())

    def check_timeout_session(self):
        dpt('>>>check timeout')
        try:
            sessions = self.generic_call_api_resp('show-sessions', cache=False)
            for row, obj in enumerate(sessions):
                if not isinstance(obj, dict):
                    break
                uid = obj.get('uid')
                user_name = obj.get('user-name')
                app = obj.get('application')
                in_work = obj.get('in-work')
                last_lg_tm = obj.get('last-login-time')
                session_timeout = obj.get('session-timeout')
                if isinstance(last_lg_tm, str) and last_lg_tm.find('{') != -1:
                    last_lg_tm = json.loads(last_lg_tm)
                
                #sid cache, last-login-time come from checkpoint, unit is ms
                data = last_lg_tm.get('posix')
                now = int(self._last_login_time)
                delta_time = (now - data) / 1000
                if (user_name == self._user and app == 'WEB_API') and (
                        in_work is False or delta_time > session_timeout):
                    self.logout_session(uid=uid, clear_cache=True)
            return True
        except Exception:
            dpt(traceback.format_exc())
            return False

    def normalize_json_string(self, res):
        return res.replace('\n', '').replace('\"', '"').replace('ISODate(', '"').replace('Z)', 'Z"')

    def escape_db_query_string(self, query_string):
        return query_string.replace('/', '\\/').replace('[', '\\[').replace(']', '\\]')

    def check_version(self, version):
        cp_val_grp = re.compile(r'r(\d+)', re.I).search(version)
        cp_ver = int(cp_val_grp.group(1)) if cp_val_grp else 0
        return cp_ver

    def check_license(self):
        self._discover_flag = True

        # query_condition = {'nbPathValue': {'$regex': '^{0}'.format(self._instance_id)}}
        # dev_res = CDBHelper.query_data_from_db(self._domain_db_name, 'Device', query_condition)

        res = self.generic_call_api_resp('show-gateways-and-servers')
        if not res:
            err_msg = str(self.err_msg)
            if isinstance(self.err_msg, dict):
                _body = self.err_msg.get('body')
                try:
                    _body_dct = json.loads(_body) if _body else {}
                    err_msg = _body_dct.get('message') or _body
                except Exception:
                    err_msg = _body
            return {
                'result': False,
                'log': str(err_msg)
            }
        r80_new_count = 0
        r77_new_count = 0
        found_nodes = dict()
        for item in res:
            version = item.get('version') or ''
            cp_ver = self.check_version(version)
            if cp_ver < 80 and cp_ver != 0:
                r77_new_count += 1
                found_nodes.setdefault(2007, {})
                found_nodes[2007][item['name']] = item.get('ipv4-address') if item.get('ipv4-address') else item[
                    'name']
            else:
                r80_new_count += 1
                found_nodes.setdefault(30080, {})
                found_nodes[30080][item['name']] = item.get('ipv4-address') if item.get('ipv4-address') else item[
                    'name']

        log = 'Retrieval Completed: Found {0} CheckPoint R80 firewall, {1} CheckPoint firewall.\r\n'.format(
            r80_new_count, r77_new_count)
        return {
            'result': True,
            'new': {30080: r80_new_count, 2007: r77_new_count},
            'found': found_nodes,
            'log': log
        }

    def check_device_matched(self, objects):
        name = objects.get('name')
        mgmtIP = objects.get('ipv4-address')
        _type = objects.get('type')
        if _type in ('CpmiVsxNetobj',):
            # dpt('Type mismatch: ', _type)
            return False
        if mgmtIP and not _type.startswith('CpmiVs') and mgmtIP == self._mgmtIP:
            return True
        if name and name.lower() in (self._devName.lower(), self._snmpName.lower()):
            return True
        # dpt('Device mismatch: %s[name] <--> (%s[self._devName], %s[self._snmpName])' % (
        #     name, self._devName, self._snmpName))
        return False

    # api call helper

    def gen_headers_and_body(self, path, sid='', offset=0, script='', task_id='', **kw):
        if sid:
            req_dict = {'headers': {
                'Content-Type': 'application/json',
                'X-chkp-sid': sid
            }, 'body': '{}'}
        else:
            req_dict = {'headers': {'Content-Type': 'application/json'}, 'body': {}}
        if path == 'login':
            domain = kw.get('domain')
            if domain:
                req_dict['body'] = json.dumps({
                    'user': self._user,
                    'password': self._pwd,
                    'domain': domain,
                    'session-timeout': 600,
                    # 'continue-last-session': True,
                })
            else:
                req_dict['body'] = json.dumps({
                    'user': self._user,
                    'password': self._pwd,
                    'session-timeout': 600,
                    # 'continue-last-session': True,
                })
        elif path == 'discard' and kw:
            _uid = kw.get('uid')
            if _uid:
                req_dict['body'] = json.dumps(
                    {
                        'uid': _uid,
                    }
                )
        elif path in ('publish', 'discard', 'logout'):
            pass
        elif path == 'show-gateways-and-servers':
            req_dict['body'] = json.dumps({
                "limit": 50,
                "offset": offset,
                "details-level": "full"
            })
        elif path == 'run-script':
            req_dict['body'] = json.dumps(
                {
                    "script-name": str(datetime.now()) + ' ' + script,
                    "script": script,
                    "targets": [self._devName]
                }
            )
        elif path == 'show-task':
            # here task-id is script
            req_dict['body'] = json.dumps(
                {
                    "task-id": task_id,
                    "details-level": "full"
                }
            )
        elif path == 'show-nat-rulebase':
            package_name = kw.get('package') or "standard"
            req_dict['body'] = json.dumps({
                "limit": 50,
                "offset": offset,
                "details-level": "standard",
                "use-object-dictionary": True,
                "package": package_name
            })
        elif path == 'show-access-rulebase' and kw:
            package_name = kw.get('package')
            access_name = kw.get('name')
            if package_name and access_name:
                req_dict['body'] = json.dumps({
                    "limit": 50,
                    "offset": offset,
                    "package": package_name,
                    "name": access_name,
                    "details-level": "standard",
                    "use-object-dictionary": True
                })
        elif path.startswith('show-service-') or path.startswith('show-group-with-exclusion') and kw:
            name = kw.get('name')
            req_dict['body'] = json.dumps({
                "name": name
            })
        elif path == 'show-groups':
            body = {
                "limit": 50,
                "offset": offset,
                "details-level": "full",
            }
            if self._api_ver >= 1.3:
                body['show-as-ranges'] = 'true'
            req_dict['body'] = json.dumps(body)
        elif path == 'show-group' and kw:
            req_dict['body'] = json.dumps({
                'name': kw.get('name'),
            })
        else:
            req_dict['body'] = json.dumps({
                "limit": 50,
                "offset": offset,
                "details-level": "full"
            })

        return req_dict
    
    def get_resp(self, url, params):
        self.err_msg = ''
        if self.status_code == 999:
            return None
        dpt("get_resp, url=" + url + ", params=" + str(params))
        try:
            if is_fs_side:
                locks = Locks.getInstance()
                locks.update_lock(self._url)
                status_code = 429
                counter = 1
                login_resp = None
                while status_code == 429 and counter < 4:
                    # dpt('Too many requests')
                    lock = locks.endpoint2locks[self._url]
                    log = StatLog.getInstance()
                    #log.requestEntry({'type':'lock'})
                    
                    req = NBRequest(endpoint = self._url,url = url,header = params['headers'],body=params['body'])
                    
                    req.proxies = self._proxies
                    req.timeout = g_http_timeout
                    
                    mgr = locks.nbRequestMgr
                    login_resp = mgr.post(req)

                    try:
                        log.requestEntry({'type':'post','url':url,'body':params['body']})
                    except Exception as e:
                        log.requestExist()
                        dpt(e)
                        return None
                    log.requestExist()
                    if login_resp:
                        status_code = login_resp.status_code
                        self.status_code = status_code

                    counter += 1

                if login_resp and login_resp.status_code == requests.codes.ok and login_resp.text.startswith('{'):
                    return login_resp.json()
                else:
                    self.err_msg = login_resp.text
                    if self.err_msg:
                        try:
                            context = json.loads(self.err_msg)
                            _code = context.get('code')
                            if _code == 'generic_err_wrong_session_id':
                                dpt('check session id and resend the request')
                                key = self.generate_session_key()
                                self.clear_session_cache(key, ttl=-1)
                                self._init_session()
                                headers = params.get('headers') or {}
                                x_sid = headers.get('X-chkp-sid')
                                if x_sid:
                                    params['headers']['X-chkp-sid'] = self._sid

                                return self.get_resp(url, params)
                        except Exception:
                            dpt(traceback.format_exc())
                    dpt('FS log', self.err_msg)
            elif is_worker_side:
                ip_addr = self._url.partition('://')[2].partition('/')[0].partition(':')[0]
                login_http_req_param = {
                    'url': url,
                    'headers': params['headers'],
                    'body': params['body'],
                    'ipAddress': ip_addr,
                    'apID': self._ap_id,
                    'method': 'POST'
                }
                if self._proxies:
                    login_http_req_param['proxies'] = self._proxies
                resp = json.loads(pythonlib.get_api_response(json.dumps(login_http_req_param)))
                if resp.get('status_code') == 200:
                    resp_body = resp.get('body')
                    return json.loads(resp_body)
                else:
                    self.err_msg = resp
                    dpt('WorkerServer log', self.err_msg)
        except Exception as e:
            dpt(self.err_msg)
            self.err_msg = e.message if hasattr(e, 'message') else str(e)
            dpt(e)
            dpt(traceback.format_exc())
            dpt(url, params)

        return None

    def logout_session(self, uid='', sid='', url='', clear_cache=False):
        _url = url or self._url
        _sid = sid or self._sid
        if clear_cache:
            discard_para = self.gen_headers_and_body('discard', sid=_sid, uid=uid)
            discard_resp_info = self.get_resp(_url + 'discard', discard_para)
            if discard_resp_info:
                dpt('discard session uid:"%s" successfully' % uid)
                time.sleep(0.5)
        else:
            # # publish
            # publish_para = self.gen_headers_and_body('publish', _sid)
            # publish_resp_info = self.get_resp(_url + 'publish', publish_para)
            # if publish_resp_info:
            #     dpt('publish session id:"%s" successfully' % _sid)
            #     time.sleep(1)
            #     # dpt('publish response: ', publish_resp_info)

            # discard
            discard_para = self.gen_headers_and_body('discard', _sid)
            discard_resp_info = self.get_resp(_url + 'discard', discard_para)
            if discard_resp_info:
                dpt('discard session id:"%s" successfully' % _sid)
                time.sleep(0.5)
                # dpt('discard response: ', discard_resp_info)

            # logout this session
            logout_para = self.gen_headers_and_body('logout', _sid)
            logout_resp_info = self.get_resp(_url + 'logout', logout_para)
            if logout_resp_info:
                dpt('logout session id:"%s" successfully' % _sid)
                time.sleep(0.5)  # waiting for logout complete!
                # dpt('logout response: ', logout_resp_info)

    def modify_objects(self, objects):

        def __get_new_uid(prnt_uid, row):
            new_uid = ''
            parent_uid = uuid.UUID(prnt_uid)
            if isinstance(parent_uid, uuid.UUID):
                uuid_int = parent_uid.int
                new_uid = uuid.UUID(int=uuid_int + row)
            return str(new_uid) or prnt_uid

        cld_index = dict()
        cls_parent = dict()
        for row, obj in enumerate(objects):
            if not isinstance(obj, dict):
                break
            _type = obj.get('type')
            if _type in ('CpmiVsClusterNetobj',):
                cls_names = obj.get('cluster-member-names') or []
                if cls_names:
                    parent_uid = obj.get('uid')
                    for index, cls_name in enumerate(cls_names):
                        new_obj = copy.copy(obj)
                        new_obj['uid'] = __get_new_uid(parent_uid, index + 1)
                        new_obj['name'] = cls_name
                        new_obj['type'] = 'CpmiVsCluster'
                        new_obj.pop('cluster-member-names')
                        objects.insert(row + index + 1, new_obj)
                    objects.pop(row)

            # modify vpn:
            # vpn-community-star: show-vpn-communities-star
            # vpn-community-meshed: show-vpn-communities-meshed
            if _type in ('vpn-community-star', 'vpn-community-meshed'):
                def _modify_vpn_objects(obj_lst):
                    for row, obj in enumerate(obj_lst):
                        _type = obj.get('type')
                        if _type in ('CpmiGatewayCluster', 'CpmiVsClusterNetobj'):
                            _name = obj.get('name')
                            cls_name_lst = self._cluster_map.get(_name)
                            for cls_name in cls_name_lst:
                                new_obj = dict()
                                new_obj['name'] = cls_name
                                obj_lst.append(new_obj)
                            obj_lst.pop(row)

                meshed_gws = obj.get('gateways') or []
                _modify_vpn_objects(meshed_gws)
                center_gws = obj.get('center-gateways') or []
                _modify_vpn_objects(center_gws)
                satellite_gws = obj.get('satellite-gateways') or []
                _modify_vpn_objects(satellite_gws)

            ver = obj.get('version')
            name = obj.get('name')
            hardware = obj.get('hardware')
            policy = obj.get('policy') or {}
            vpn = obj.get('vpn-encryption-domain') or ''
            manual_defined = obj.get('vpn-encryption-domain-manually-defined') or {}
            new_objs = {
                'version': ver,
                'hardware': hardware,
                'policy': policy,
                'vpn-encryption-domain': vpn,
                'vpn-encryption-domain-manually-defined': manual_defined
            }
            if name:
                if _type in ('CpmiGatewayCluster', 'CpmiVsClusterNetobj'):
                    cls_names = obj.get('cluster-member-names') or []
                    if cls_names:
                        for cls_name in cls_names:
                            if not self._cluster_map.get(name):
                                self._cluster_map[name] = [cls_name]
                            else:
                                if cls_name not in self._cluster_map.get(name):
                                    self._cluster_map[name].append(cls_name)

                if name in cls_parent:
                    obj.update(cls_parent.get(name))
                else:
                    cld_index[name] = row
            mbs_names = obj.get('cluster-member-names') or []
            if not (ver and hardware):
                continue
            for mb_name in mbs_names:
                if mb_name in cld_index:
                    chlid_index = cld_index.get(mb_name)
                    objects[chlid_index].update(new_objs)
                else:
                    cls_parent[mb_name] = new_objs

    def generic_call_api_resp(self, path, script='', task_id='', cache=True, **kw):
        # ctx = ssl.create_default_context
        # first login then use session id to get data
        sid = self._sid or self.get_session_id()
        if not sid:
            return []

        # second get data
        full_url = self._url + path
        dpt('start to get response of url %s' % full_url)
        call_para = self.gen_headers_and_body(path, sid, script=script, task_id=task_id, **kw)
        cache_key = None

        if _use_cache and cache:
            cache_key = self.generate_sid_cache_key(self._domain, full_url,call_para['body'])
            cache_result = self._sid_cache.get(cache_key)
            if not cache_result:
                resp = self.get_resp(full_url, call_para)
            else:
                dpt('Use cache to get response of url <%s>' % full_url)
                resp = cache_result.get('response')
                return resp
        else:
            resp = self.get_resp(full_url, call_para)

        def __extend_objects(resp, *args):
            # if entries are to much, need many segments
            to_index = resp.get('to')
            total_index = resp.get('total')
            dpt("begin to_index=" + str(to_index) + ", total_index=" + str(total_index))
            if to_index and total_index and to_index < total_index:
                call_para = self.gen_headers_and_body(path, sid, offset=to_index, **kw)
                # body = json.loads(call_para.get('body')) or {}
                # object_dct = body.get('use-object-dictionary') if body else {}
                # if object_dct:
                #     body['use-object-dictionary'] = False
                #     call_para['body'] = json.dumps(body)
                resp = self.get_resp(full_url, call_para)
                if resp and args:
                    for lst, key in args:
                        key_items = resp.get(key) or []
                        lst.extend(key_items) if key_items else lst
                        __extend_objects(resp, (lst, key))

        if isinstance(resp, dict):
            objects = resp.get('objects')
            rulebase = resp.get('rulebase')

            if isinstance(objects, list):
                __extend_objects(resp, (objects, 'objects'))
                if objects:
                    self.modify_objects(objects)
                    dpt('get objects successfully')
                    dpt('get response of url %s successfully' % full_url)
                    if cache_key:
                        self._sid_cache.set(cache_key,
                                            {'api_type': 'CheckPointR80', 'time': time.time(),
                                             'ttl': self._timeout,
                                             'url': full_url, 'domain': self._domain, 'response': objects})
                    return objects

            elif isinstance(rulebase, list):
                obj_dct = resp.get('objects-dictionary')
                __extend_objects(resp, (rulebase, 'rulebase'), (obj_dct, 'objects-dictionary'))

                if rulebase and obj_dct:
                    resp['rulebase'] = rulebase
                    resp['objects-dictionary'] = obj_dct
                    dpt('get rulebase&objects-dictionary successfully')
            dpt('get response of url %s successfully' % full_url)
            if cache_key:
                self._sid_cache.set(cache_key,
                                    {'api_type': 'CheckPointR80', 'time': time.time(), 'ttl': self._timeout,
                                     'url': full_url, 'domain': self._domain, 'response': resp})
            return resp
        return {}

    # parse virtual-system infomation

    def get_vsys_items(self, mgmt_ip=''):
        vs_dict = dict()
        run_script = self.generic_call_api_resp('run-script', script="clish -c 'show virtual-system all'") or {}
        task_lst = run_script.get('tasks') or []
        time.sleep(5)  # waiting for task process complete!
        for task_objs in task_lst:
            task_id = task_objs.get('task-id')
            task_info = self.generic_call_api_resp('show-task', task_id=task_id) or {}
            task_lst = task_info.get('tasks') or []
            for task_objs in task_lst:
                if self._domain:
                    _domain = task_objs.get('domain') or {}
                    domain_uid = _domain.get('uid')
                    if self._domain != domain_uid:
                        continue
                task_details = task_objs.get('task-details') or []
                for task_dt in task_details:
                    dm_objs = task_dt.get('domain') or {}
                    _uid = dm_objs.get('uid')
                    if _uid and self._domain != _uid:
                        continue
                    resp_msg = task_dt.get('responseMessage') or ''
                    result_text = base64.b64decode(resp_msg).decode('utf-8') or ''
                    _vs_lst = re.compile(r'^(\d+)\s+(\S+)', re.M).findall(result_text)
                    for tp_items in _vs_lst:
                        _vs_id = tp_items[0]
                        _vs_name = tp_items[1]
                        if _vs_name.isdigit():
                            continue
                        vs_dict[_vs_name] = {'vs_id': int(_vs_id), 'mgmt_ip': mgmt_ip}
        return vs_dict

    def get_vsys_info(self):
        result = self.generic_call_api_resp('show-gateways-and-servers')
        vs_dict = dict()
        uid_objs = dict()
        for objs in result:
            _type = objs.get('type')
            if not _type.startswith('CpmiVsx'):
                continue
            _name = objs.get('name')
            _ipaddr = objs.get('ipv4-address')
            _domain = objs.get('domain') or {}
            _domain_uid = _domain.get('uid')
            if not (_name or _ipaddr):
                continue
            if _domain_uid:
                dev_items = {
                    'dev_name': _name,
                    'mgmt_ip': _ipaddr
                }
                if _domain_uid not in uid_objs:
                    uid_objs[_domain_uid] = [dev_items]
                else:
                    uid_objs[_domain_uid].append(dev_items)
            else:
                self._devName = _name
                vs_dict.update(self.get_vsys_items(_ipaddr))

        for dm_uid, dev_objs in uid_objs.items():
            self._domain = dm_uid
            self.get_session_id()
            for dev_dct in dev_objs:
                dev_name = dev_dct.get('dev_name')
                mgmt_ip = dev_dct.get('mgmt_ip')
                self._devName = dev_name
                vs_dict.update(self.get_vsys_items(mgmt_ip))
            if _use_cache is False:
                self.logout_session()
        return vs_dict

    # process generic schema
    def get_checkpoint_do_not_scan_subtypes(self, db_name):
        dotscan_res = CDBHelper.query_data_from_db(db_name, 'DotScan', {})
        if dotscan_res:
            subtype_res = dotscan_res[0]['subTypes']
            if subtype_res:
                # Checkpoint R80 Firewall: 30080, Checkpoint Firewall: 2007
                for subtype in subtype_res:
                    if subtype in self._support_checkpoint_subtypes:
                        self._dotscan_skip_checkpoint_subtype.append(subtype)

    def retrieve_cpr80_data(self):
        # dpt('>>>Retrieve Data: ', self._bNeedRetrieveData, '>>>Built Topo: ', self._bNeedRebuildTopo)
        if not self._bNeedRetrieveData and self._bNeedRebuildTopo:
            dpt('No built topology required')
            return True

        else:
            dpt('start retrieve cpr80 data')
            self._discover_flag = True
            self.get_checkpoint_do_not_scan_subtypes(self._domain_db_name)
            # save obj to CheckPointR80node
            current_schema = 'CheckPointR80'
            row = {'_id': self._instance_id, 'dn': self._instance_id,
                   'name': self._url.rpartition('://')[2].partition('/')[0].partition(':')[0],
                   'nbId': self._instance_id,
                   'nbPathSchema': current_schema, 'nbPathValue': self._instance_id, 'isRealDev': False}
            CDBHelper.AddNodeByObject(row['nbPathSchema'], row)
            res = self.generic_call_api_resp('show-gateways-and-servers')
            if not res:
                return False
            dpt('start to build_real_device_intf')
            dev_dict = {item.get('name'): item for item in res}
            self.build_real_device_intf(dev_dict)
            dpt('save_network_device')
            self.save_network_device()
            return True

    def build_real_device_intf(self, dev_dict):
        for dev in dev_dict.values():
            # sec_role = dev.get('network-security-blades', {})
            # if sec_role.get('firewall') or sec_role.get('site-to-site-vpn'):
            dev_obj = {}
            dev_id = dev.get('uid')
            dev_name = dev.get('name')
            dev_type = dev.get('type')
            if dev_type in ('CpmiVsxNetobj',):
                continue
            mgmt_ip = dev.get('ipv4-address')
            dev_version = dev.get('version') or ''
            cp_ver = self.check_version(dev_version)
            dev_model = dev.get('hardware') or ''
            exist_devs = []
            # if this fw already is legacy discovered in current domain, only change multiSources
            if mgmt_ip and not dev_type.startswith('CpmiVs'):
                exist_devs = CDBHelper.QueryDeviceObjects({'mgmtIP': mgmt_ip}) or []
            if not exist_devs:
                exist_devs = CDBHelper.QueryDeviceObjects({'name': {'$regex': dev_name, '$options': '$i'}}) or \
                             CDBHelper.QueryDeviceObjects({'snmpName': {'$regex': dev_name, '$options': '$i'}}) or \
                             []
            for exist_dev in exist_devs:
                if exist_dev.get('_id'):
                    dev_id = exist_dev.get('_id')
                    subType = exist_dev.get('subType')
                    if subType not in (2007, 30080):
                        continue
                    dev_name = exist_dev.get('name') or dev_name
                    dev_obj = exist_dev
                    break
            if not (_use_api_discovery or dev_obj):
                continue

            dev_nbpathvalue = '{0}/{1}'.format(self._instance_id, dev_id)
            # Add checkpoint R77
            if cp_ver < 80 and cp_ver != 0:
                if dev_obj:
                    new_dev_obj = {
                        "model": dev_model,
                        "ver": dev_version,
                        "multiSources": [
                            {
                                "nbPathSchema": 'CheckPointR80.children.device',
                                "nbPathValue": dev_nbpathvalue
                            }
                        ]
                    }
                    dev_obj.update(new_dev_obj)
                else:
                    dev_obj = {
                        "_id": dev_id,  # must set
                        "contact": "",
                        "driverName": "Checkpoint Gaia",
                        "driverId": "30508d2a-38ee-460b-bf91-b251b7a84d57",
                        "mainType": 1002,
                        "mainTypeName": "Firewall",
                        'subType': 2007,
                        'subTypeName': "Checkpoint Firewall",
                        "mgmtIP": dev.get('ipv4-address'),
                        "mgmtIntf": '',
                        "mgmtMAC": '',
                        "model": dev_model,
                        "modules": [],
                        "name": dev_name,
                        "oid": "",
                        "sn": '',
                        "vendor": 'CheckPoint',
                        "ver": dev_version,
                        "vlan": [],
                        "vpn": [],
                        "role": '',
                        "multiSources": [
                            {
                                "nbPathSchema": 'CheckPointR80.children.device',
                                "nbPathValue": dev_nbpathvalue
                            }
                        ]
                    }
            # Add checkpoint RR80
            else:
                if dev_obj:
                    new_dev_obj = {
                        "model": dev_model,
                        "ver": dev_version,
                        "multiSources": [
                            {
                                "nbPathSchema": 'CheckPointR80.children.device',
                                "nbPathValue": dev_nbpathvalue
                            }
                        ]
                    }
                    dev_obj.update(new_dev_obj)
                else:
                    dev_obj = {
                        "_id": dev_id,  # must set
                        "contact": "",
                        "driverName": "Checkpoint Gaia R80",
                        "driverId": "b1ff9952-89e0-4e79-bec8-e8b0c9a56bd5",
                        "mainType": 1002,
                        "mainTypeName": "Firewall",
                        'subType': 30080,
                        'subTypeName': "Checkpoint Firewall R80",
                        "mgmtIP": dev.get('ipv4-address'),
                        "mgmtIntf": '',
                        "mgmtMAC": '',
                        "model": dev_model,
                        "modules": [],
                        "name": dev_name,
                        "oid": "",
                        "sn": '',
                        "vendor": 'CheckPoint',
                        "ver": dev_version,
                        "vlan": [],
                        "vpn": [],
                        "role": '',
                        "multiSources": [
                            {
                                "nbPathSchema": 'CheckPointR80.children.device',
                                "nbPathValue": dev_nbpathvalue
                            }
                        ]
                    }
            self._legacy_real_devices[dev_id] = dev_obj

    def save_network_device(self):
        found_r80_device_count = 0
        found_firewall_device_count = 0
        donotscan_device_count = {}
        if _use_api_discovery:
            vs_dict = self.get_vsys_info()
        else:
            vs_dict = {}
        # dpt('>>>lg_dct: ', self._legacy_real_devices.values())
        # dpt('>>>vs_dct: ', vs_dict)
        for device in self._legacy_real_devices.values():
            ls = None
            dev_name = device.get('name')
            if dev_name in vs_dict:
                param_info = vs_dict[dev_name]
                parent_mgmt_ip = param_info.get('mgmt_ip')
                vs_id = param_info.get('vs_id')
                ls = CDBHelper.LoginScript()
                ls.add_non_priviledge_item('#', 'clish')
                ls.add_non_priviledge_item('>', 'set clienv rows 0')
                ls.add_non_priviledge_item('>', 'set virtual-system %s' % vs_id)
                ls.add_non_priviledge_item('>', 'set clienv rows 0')
                ls.add_non_priviledge_item('>', '')
                if parent_mgmt_ip:
                    device['mgmtIP'] = parent_mgmt_ip

            dev_subType = device.get('subType', 0)
            dev_mgmtIP = device.get('mgmtIP', '')

            # save devcie failed: do not scan, node license reach limit
            ret_res = CDBHelper.AddDeviceByObject(device)
            if ret_res:
                # summary info
                if dev_subType == 30080:
                    found_r80_device_count += 1
                    self.discover_results['found'][30080][dev_name] = dev_mgmtIP if dev_mgmtIP != '' else dev_name
                elif dev_subType == 2007:
                    found_firewall_device_count += 1
                    self.discover_results['found'][2007][dev_name] = dev_mgmtIP if dev_mgmtIP != '' else dev_name

                # save device setting when success save device
                if ls:
                    CDBHelper.SetDeviceSettings(device['name'], device['driverId'], device['subType'],
                                                device.get('mgmtIP', ''),
                                                self._ap_id, self._external_server_id, self._tech_id,
                                                device_id=device['_id'], login_script=ls)
                else:
                    CDBHelper.SetDeviceSettings(device['name'], device['driverId'], device['subType'],
                                                device.get('mgmtIP', ''),
                                                self._ap_id, self._external_server_id, self._tech_id,
                                                device_id=device['_id'])
            elif dev_subType in self._dotscan_skip_checkpoint_subtype:
                if dev_subType not in donotscan_device_count:
                    donotscan_device_count[dev_subType] = 1
                else:
                    donotscan_device_count[dev_subType] += 1
        donotscan_device_log = ''
        if donotscan_device_count:
            for subType in donotscan_device_count:
                if subType == 30080:
                    donotscan_device_log += 'The Device Type Checkpoint Firewall R80 is in the Do-Not-Scan list. Device Count: {0}\r\n'.format(
                        donotscan_device_count[subType])
                elif subType == 2007:
                    donotscan_device_log += 'The Device Type Checkpoint Firewall is in the Do-Not-Scan list. Device Count: {0}\r\n'.format(
                        donotscan_device_count[subType])
        discover_summary_log = 'Retrieval Completed: Found {0} CheckPoint R80+ firewall, {1} CheckPoint firewall.\r\n'.format(
            found_r80_device_count, found_firewall_device_count)
        self.discover_results['log'] = donotscan_device_log + discover_summary_log

    # parsed nct table

    def parse_addr(self, addr_dict):
        def __parse_group_name(name, ex=False):
            grp_addr_lst = list()
            groups_list = self.generic_call_api_resp('show-groups') or []
            for group_dct in groups_list:
                if not isinstance(group_dct, dict):
                    continue
                grp_name = group_dct.get('name')
                if grp_name != name:
                    continue
                if not (group_dct.get('members') or group_dct.get('ranges')):
                    group_dct = self.generic_call_api_resp('show-group', name=grp_name) or {}
                grp_members = group_dct.get('members') or list()
                ranges = group_dct.get('ranges') or dict()
                if grp_members:
                    for mbs_dct in grp_members:
                        _addr = ''
                        mbs_type = mbs_dct.get('type')
                        if mbs_type == 'group':
                            iter_mb_name = mbs_dct.get('name')
                            iter_mb_type = mbs_dct.get('type')
                            if iter_mb_type == 'group' and iter_mb_name:
                                __parse_group_name(iter_mb_name, ex)
                            elif iter_mb_type == 'group-with-exclusion' and iter_mb_name:
                                __parse_group_name(iter_mb_name, ex)
                        else:
                            _addr = self.parse_addr(mbs_dct)
                        if _addr:
                            addr.append(_addr)
                            if ex:
                                _addr = '|%s' % _addr
                            grp_addr_lst.append(_addr)
                elif ranges:
                    ipv4_lst = ranges.get('ipv4') or list()
                    for _ipv4_rg in ipv4_lst:
                        _addr = self.parse_addr(_ipv4_rg)
                        if _addr:
                            addr.append(_addr)
                            grp_addr_lst.append(_addr)

            return grp_addr_lst

        addr = list()
        _addr = ''
        host_addr = addr_dict.get('ipv4-address')
        ntwk_ipv4 = addr_dict.get('subnet4')
        ntwk_maskv4 = addr_dict.get('mask-length4')
        rg_addr_head = addr_dict.get('ipv4-address-first') or addr_dict.get('start')
        rg_addr_tail = addr_dict.get('ipv4-address-last') or addr_dict.get('end')
        _type = addr_dict.get('type') or ''
        if host_addr:
            _addr = host_addr
        elif ntwk_ipv4 and ntwk_maskv4:
            _addr = '%s/%s' % (ntwk_ipv4, ntwk_maskv4)
        elif rg_addr_head and rg_addr_tail:
            _addr = '%s-%s' % (rg_addr_head, rg_addr_tail)
        else:
            if _type == 'CpmiAnyObject':
                _addr = '0.0.0.0/0'
            elif _type == 'group-with-exclusion':
                grp_name = addr_dict.get('name')
                grp_ex_objs = self.generic_call_api_resp('show-group-with-exclusion', name=grp_name)
                _include = grp_ex_objs.get('include') or {}
                _in_name = _include.get('name')
                if _in_name:
                    in_addr = __parse_group_name(_in_name)
                _except = grp_ex_objs.get('except') or {}
                _ex_name = _except.get('name')
                if _ex_name:
                    ex_addr = __parse_group_name(_ex_name, True)
                if in_addr and ex_addr:
                    addr.clear()
                    _addr = [adr for adr in zip(in_addr, ex_addr)]
            elif _type == 'group':
                grp_name = addr_dict.get('name')
                if grp_name:
                    __parse_group_name(grp_name)

        if _addr:
            if isinstance(_addr, list):
                for in_adr, ex_adr in _addr:
                    addr.append('%s%s' % (in_adr, ex_adr))
            else:
                addr.append(_addr)
        return ', '.join(addr).strip(', ')

    def parse_service(self, service_dict, original_port=''):
        services = list()
        _name = service_dict.get('name')
        _type = service_dict.get('type')
        protocol = ''
        port = service_dict.get('port') or '0-65535'
        if _type.lower() == 'global':
            if original_port:
                port = original_port
        if _type in ('CpmiAnyObject',):
            protocol = 'ip'
        elif _type in ('CpmiGtpMmV0Service',):
            protocol = 'gtp'
        elif _type == 'service-tcp':
            protocol = 'tcp'
        elif _type == 'service-udp':
            protocol = 'udp'
        elif _type == 'service-sctp':
            protocol = 'sctp'
        elif _type == 'service-rpc':
            protocol = 'rpc'
            objs = self.generic_call_api_resp('show-service-rpc', name=_name)
            num = objs.get('program-number')
            if num:
                port = num
        elif _type == 'service-dce-rpc':
            protocol = 'rpc'
        elif _type in ('service-icmp', 'service-icmp6'):
            protocol = 'icmp'
        elif _type == 'service-other':
            objs = self.generic_call_api_resp('show-service-other', name=_name)
            protocol = objs.get('ip-protocol') or _type
        elif _type == 'service-group':
            objs = self.generic_call_api_resp('show-service-group', name=_name)
            mb_lst = objs.get('members')
            for mb_objs in mb_lst:
                srvs = self.parse_service(mb_objs)
                for proto, po in srvs:
                    services.append((proto, po))
        else:
            protocol = _type
        if protocol:
            services.append((str(protocol), str(port)))
        return services

    def build_objs_dct(self, objs):
        objs_dict = {}
        for obj in objs:
            uid = obj.get('uid')
            if uid:
                objs_dict[uid] = obj
        return objs_dict

    def get_policy_table(self):

        def __update_policy_dict(rulebase_list, objects_dict):
            nonlocal has_policy
            nonlocal count
            for rulebase_objs in rulebase_list:
                if 'rulebase' in rulebase_objs:
                    __update_policy_dict(rulebase_objs.get('rulebase'), objects_dict)
                    continue

                # Disable
                disable = 'false'
                enable = rulebase_objs.get('enabled')
                if not enable:
                    disable = 'true'

                # Name
                name = rulebase_objs.get('name', '')

                # Src
                src_id_lst = rulebase_objs.get('source') or []
                src_negate = rulebase_objs.get('source-negate') or ''
                src_addr_lst = [self.parse_addr(objects_dict.get(src_id, {})) for src_id in src_id_lst]
                if src_negate:
                    src_addr_lst = ['!%s' % src_addr for src_addr in src_addr_lst]
                src = ', '.join(src_addr_lst).strip(', ')

                # Dst
                dst_id_lst = rulebase_objs.get('destination')
                dst_negate = rulebase_objs.get('destination-negate') or ''
                dst_addr_lst = [self.parse_addr(objects_dict.get(dst_id, {})) for dst_id in dst_id_lst]
                if dst_negate:
                    dst_addr_lst = ['!%s' % dst_addr for dst_addr in dst_addr_lst]
                dst = ', '.join(dst_addr_lst).strip(', ')

                # Action
                action_id = rulebase_objs.get('action')
                action_objs = objects_dict.get(action_id) or {}
                action = action_objs.get('name', '').lower()

                # Service
                count += 1
                protocols = []
                ports = []
                srvs = []
                srv_id_lst = rulebase_objs.get('service') or []
                srv_negate = rulebase_objs.get('service-negate') or ''
                for srv_id in srv_id_lst:
                    srv_objs = objects_dict.get(srv_id, {})
                    srv_name = srv_objs.get('name')
                    srvs.append(srv_name)
                    srv_tps = self.parse_service(srv_objs)
                    if not srv_tps:
                        continue
                    for protocol, port in srv_tps:
                        has_policy = True
                        if srv_negate:
                            protocol = '!%s' % protocol
                            port = '!%s' % port
                        protocols.append(protocol)
                        ports.append(port)
                append_num(count)
                append_disable(disable)
                append_name(name)
                append_src(src)
                append_dst(dst)
                append_protocol(', '.join(protocols))
                append_port(', '.join(ports))
                append_srv_name(', '.join(srvs))
                append_action(action)

        dpt('Start to get policy table')
        table_name = 'Policy Table'
        sub_name = ''
        policy_table = NCTTable(self._devName, table_name, sub_name)
        gateway_list = self.generic_call_api_resp('show-gateways-and-servers') or []
        group_list = self.generic_call_api_resp('show-groups') or []
        packages = self.generic_call_api_resp('show-packages') or {}
        if not gateway_list:
            policy_table.SetStatus(NCTStatus.Failed)
            msg = 'Failed to retrieve Policy'
            dpt(msg)
            dpt('#====== Policy ======#\n', 'No gateways-and-servers was found')
            # policy_table.AddLog(msg)
            return False

        has_policy = False
        count = 0
        policy_dict = dict()
        policy_dict['No.'] = []
        policy_dict['Disable'] = []
        policy_dict['Name'] = []
        policy_dict['Src'] = []
        policy_dict['Dst'] = []
        policy_dict['Protocol'] = []
        policy_dict['Port'] = []
        policy_dict['Service Name'] = []
        policy_dict['Action'] = []

        append_num = policy_dict['No.'].append
        append_disable = policy_dict['Disable'].append
        append_name = policy_dict['Name'].append
        append_src = policy_dict['Src'].append
        append_dst = policy_dict['Dst'].append
        append_protocol = policy_dict['Protocol'].append
        append_port = policy_dict['Port'].append
        append_srv_name = policy_dict['Service Name'].append
        append_action = policy_dict['Action'].append

        policy_content_lst = []
        policy_content_lst.append('%s#show-groups\n%s' % (self._devName, json.dumps(group_list, indent=2)))
        for gateway_objs in gateway_list:
            dev_matched = self.check_device_matched(gateway_objs)
            if not dev_matched:
                continue
            policy_objs = gateway_objs.get('policy') or {}
            policy_content_lst.append(
                '%s#show-gateways-and-servers\n%s' % (self._devName, json.dumps(policy_objs, indent=2)))
            policy_name = policy_objs.get('access-policy-name', '')
            if not policy_name:
                continue
            policy_content_lst.append('%s#show-packages\n%s' % (self._devName, json.dumps(packages, indent=2)))
            package_lst = packages.get('packages') or []
            for package_objs in package_lst:
                package_name = package_objs.get('name')
                if policy_name != package_name:
                    continue
                _access = package_objs.get('access')
                if not _access:
                    continue
                access_lst = package_objs.get('access-layers') or []
                for access_objs in access_lst:
                    access_name = access_objs.get('name')
                    policy_info = {
                        "package": package_name,
                        "name": access_name,
                    }
                    policy_content_lst.append(json.dumps(policy_info, indent=2))
                    access_rulebase = self.generic_call_api_resp('show-access-rulebase',
                                                                 **policy_info) or {}
                    policy_content_lst.append('%s#show-access-rulebase\n%s' % (
                        self._devName, json.dumps(access_rulebase, indent=2)))
                    objs_dct = access_rulebase.get('objects-dictionary') or {}
                    rulebase_lst = access_rulebase.get('rulebase') or []
                    if not (objs_dct and rulebase_lst):
                        continue
                    ply_objs_dict = self.build_objs_dct(objs_dct)
                    __update_policy_dict(rulebase_lst, ply_objs_dict)

        if has_policy:
            policy_table.SetColumns(
                ['No.', 'Disable', 'Name', 'Src', 'Dst', 'Protocol',
                 'Port', 'Service Name', 'Action'])
            policy_table.GetColumns().update(policy_dict)
            policy_table.SetKeys(
                ['Disable', 'Src', 'Dst', 'Action'])
            policy_table.SetIgnores(['No.', 'Service Name'])
            policy_table.SetStatus(NCTStatus.Success)
            msg = 'Retrieve Policy Table successfully.'
            dpt(msg)
            # policy_table.AddLog(msg)
        else:
            policy_table.SetStatus(NCTStatus.NA)
            msg = 'No Policy Table found.'
            dpt(msg)
            # policy_table.AddLog(msg)

        policy_content = '\r\n'.join(policy_content_lst)
        if _nct_details:
            dpt('#====== Policy ======#\n', policy_content)
        # policy_table.SetOriginalText(policy_content)
        return policy_table.save_to_csv()

    def get_nat_table(self):

        def __update_nat_dict(rulebase_list, objects_dict):
            nonlocal has_nat
            for rulebase in rulebase_list:
                if 'rulebase' in rulebase:
                    __update_nat_dict(rulebase.get('rulebase'), objects_dict)
                    continue

                nat_type = ''
                protocol = ''
                in_intf = 'any'
                out_intf = 'any'
                src_ip = ''
                src_port = ''
                trans_src_ip = ''
                trans_src_port = ''
                dst_ip = ''
                dst_port = ''
                trans_dst_ip = ''
                trans_dst_port = ''
                match_info = []

                # check install-on
                installed = False
                install_lst = rulebase.get('install-on')
                for install_id in install_lst:
                    install_objs = objects_dict.get(install_id)
                    name = install_objs.get('name')
                    if name == dev_name or name.lower() in ('all', 'policy targets'):
                        installed = True
                        break
                if not installed:
                    continue

                # nat type
                method = rulebase.get('method')
                if method == 'hide':
                    nat_type = 'dynamic'
                elif method == 'static':
                    nat_type = 'static'

                # source ip
                src_ip_id = rulebase.get('original-source')
                if src_ip_id:
                    src_ip_dct = objects_dict.get(src_ip_id)
                    match_info.append(json.dumps(src_ip_dct, indent=2))
                    src_ip = self.parse_addr(src_ip_dct) or ''

                # translated source ip
                trans_src_ip_id = rulebase.get('translated-source')
                if trans_src_ip_id:
                    trans_src_ip_dict = objects_dict.get(trans_src_ip_id)
                    match_info.append(json.dumps(trans_src_ip_dict, indent=2))
                    trans_src_ip = self.parse_addr(objects_dict.get(trans_src_ip_id)) or ''

                # destination ip
                dst_ip_id = rulebase.get('original-destination')
                if dst_ip_id:
                    dst_ip_dct = objects_dict.get(dst_ip_id)
                    match_info.append(json.dumps(dst_ip_dct, indent=2))
                    dst_ip = self.parse_addr(objects_dict.get(dst_ip_id)) or ''

                # translated destination ip
                trans_dst_ip_id = rulebase.get('translated-destination')
                if trans_dst_ip_id:
                    trans_dst_ip_dct = objects_dict.get(trans_dst_ip_id)
                    match_info.append(json.dumps(trans_dst_ip_dct, indent=2))
                    trans_dst_ip = self.parse_addr(objects_dict.get(trans_dst_ip_id)) or ''

                # protocol & destination port
                ori_srv_id = rulebase.get('original-service')
                trans_srv_id = rulebase.get('translated-service')
                if ori_srv_id:
                    srv_dict = objects_dict.get(ori_srv_id)
                    if srv_dict:
                        match_info.append(json.dumps(srv_dict, indent=2))
                    trans_srv = objects_dict.get(trans_srv_id)
                    if trans_srv:
                        match_info.append(json.dumps(trans_srv, indent=2))
                    match_info = '%s#show-nat-rulebase\nrulebase %s\nobjects-dictionary %s' % (
                        self._devName, json.dumps(rulebase, indent=2), '\n'.join(match_info))
                    srv_tps = self.parse_service(srv_dict)
                    for protocol, dst_port in srv_tps:
                        has_nat = True
                        trans_srv_tps = self.parse_service(trans_srv, dst_port)
                        if trans_srv_tps:
                            for trans_protocol, trans_dst_port in trans_srv_tps:
                                append_in_intf(in_intf)
                                append_out_intf(out_intf)
                                append_protocol(protocol)
                                append_src_ip(src_ip)
                                append_src_port(src_port)
                                append_trans_src_ip(trans_src_ip)
                                append_trans_src_port(trans_src_port)
                                append_dst_ip(dst_ip)
                                append_dst_port(dst_port)
                                append_trans_dst_ip(trans_dst_ip)
                                append_trans_dst_port(trans_dst_port)
                                append_type(nat_type)
                                append_match_info(match_info)
                        else:
                            append_in_intf(in_intf)
                            append_out_intf(out_intf)
                            append_protocol(protocol)
                            append_src_ip(src_ip)
                            append_src_port(src_port)
                            append_trans_src_ip(trans_src_ip)
                            append_trans_src_port(trans_src_port)
                            append_dst_ip(dst_ip)
                            append_dst_port(dst_port)
                            append_trans_dst_ip(trans_dst_ip)
                            append_trans_dst_port(trans_dst_port)
                            append_type(nat_type)
                            append_match_info(match_info)

        dpt('Start to get nat table')
        table_name = 'NAT Table'
        sub_name = ''
        dev_name = ''
        nat_table = NCTTable(self._devName, table_name, sub_name)
        
        nat_content_lst = []
        group_list = self.generic_call_api_resp('show-groups') or []
        gateway_list = self.generic_call_api_resp('show-gateways-and-servers') or []
        nat_rulebase = {}
        for gateway_objs in gateway_list:
            dev_matched = self.check_device_matched(gateway_objs)
            if not dev_matched:
                continue
            dev_name = gateway_objs.get('name')
            policy_objs = gateway_objs.get('policy') or {}
            nat_content_lst.append(
                '%s#show-gateways-and-servers\n%s' % (self._devName, json.dumps(policy_objs, indent=2)))
            policy_name = policy_objs.get('access-policy-name', '')
            if not policy_name:
                continue
            package_info = {
                'package': policy_name
            }
            nat_rulebase = self.generic_call_api_resp('show-nat-rulebase', **package_info) or {}
            break

        nat_rule_lst = nat_rulebase.get('rulebase') or []
        if not nat_rule_lst:
            nat_table.SetStatus(NCTStatus.Failed)
            msg = 'Failed to retrieve NAT'
            dpt(msg)
            nat_content = '\r\n'.join(nat_content_lst)
            dpt('#====== NAT ======#\n', nat_content)
            # nat_table.AddLog(msg)
            return False

        # debug
        nat_content_lst.append('%s#show-groups\n%s' % (self._devName, json.dumps(group_list, indent=2)))
        nat_content_lst.append('%s#show-nat-rulebase\n%s' % (self._devName, json.dumps(nat_rulebase, indent=2)))

        has_nat = False
        nat_dict = dict()
        nat_dict['Inside Interface'] = []
        nat_dict['Outside Interface'] = []
        nat_dict['Protocol'] = []
        nat_dict['Inside Local'] = []
        nat_dict['Inside Local Port'] = []
        nat_dict['Inside Global'] = []
        nat_dict['Inside Global Port'] = []
        nat_dict['Outside Local'] = []
        nat_dict['Outside Local Port'] = []
        nat_dict['Outside Global'] = []
        nat_dict['Outside Global Port'] = []
        nat_dict['NAT Type'] = []
        nat_dict['Match Info'] = []

        append_in_intf = nat_dict['Inside Interface'].append
        append_out_intf = nat_dict['Outside Interface'].append
        append_protocol = nat_dict['Protocol'].append
        append_src_ip = nat_dict['Inside Local'].append
        append_src_port = nat_dict['Inside Local Port'].append
        append_trans_src_ip = nat_dict['Inside Global'].append
        append_trans_src_port = nat_dict['Inside Global Port'].append
        append_dst_ip = nat_dict['Outside Local'].append
        append_dst_port = nat_dict['Outside Local Port'].append
        append_trans_dst_ip = nat_dict['Outside Global'].append
        append_trans_dst_port = nat_dict['Outside Global Port'].append
        append_type = nat_dict['NAT Type'].append
        append_match_info = nat_dict['Match Info'].append

        nat_objs_dict = self.build_objs_dct(nat_rulebase.get('objects-dictionary')) or {}
        __update_nat_dict(nat_rule_lst, nat_objs_dict)

        if has_nat:
            nat_table.SetColumns(
                ['Inside Interface', 'Outside Interface', 'Protocol', 'Inside Local', 'Inside Local Port',
                 'Inside Global', 'Inside Global Port', 'Outside Local', 'Outside Local Port', 'Outside Global',
                 'Outside Global Port', 'NAT Type', 'Match Info'])
            nat_table.GetColumns().update(nat_dict)
            nat_table.SetKeys(
                ['Inside Local', 'Inside Global', 'Outside Local', 'Outside Global'])
            nat_table.SetIgnores(['Match Info'])
            nat_table.SetStatus(NCTStatus.Success)
            msg = 'Retrieve NAT Table successfully.'
            dpt(msg)
            # nat_table.AddLog(msg)
        else:
            nat_table.SetStatus(NCTStatus.NA)
            msg = 'No NAT Table found.'
            dpt(msg)
            # nat_table.AddLog(msg)

        nat_content = '\r\n'.join(nat_content_lst)
        if _nct_details:
            dpt('#====== NAT ======#\n', nat_content)
        # nat_table.SetOriginalText(nat_content)
        log.taskExit()
        return nat_table.save_to_csv()

    def build_ipsec_data(self):
        gateway_list = self.generic_call_api_resp('show-gateways-and-servers') or []
        ipsec_dict = dict()
        for gateway_dct in gateway_list:
            name = gateway_dct.get('name')
            if name:
                ipsec_dict[name] = dict()
                proxy_identity = ''
                vpn_intf = 'any'
                ipv4_addr = gateway_dct.get('ipv4-address')
                intfs = gateway_dct.get('interfaces') or []
                for intf in intfs:
                    intf_addr = intf.get('ipv4-address')
                    if intf_addr == ipv4_addr:
                        vpn_intf = intf.get('interface-name')
                        break
                vpn_type = gateway_dct.get('vpn-encryption-domain')
                if vpn_type == 'manual':
                    vpn_addr_dct = gateway_dct.get('vpn-encryption-domain-manually-defined')
                    proxy_identity = self.parse_addr(vpn_addr_dct)
                elif vpn_type == 'addresses_behind_gw':
                    intfs = gateway_dct.get('interfaces')
                    proxy_pool = []
                    for intf in intfs:
                        _ip = intf.get('ipv4-address')
                        _mask = intf.get('ipv4-mask-length')
                        proxy_pool.append('%s/%s' % (_ip, _mask))
                    proxy_identity = ', '.join(proxy_pool)
                if proxy_identity:
                    ipsec_dict[name]['vpn_address'] = ipv4_addr
                    ipsec_dict[name]['traffic_ip'] = proxy_identity
                    ipsec_dict[name]['vpn_intf'] = vpn_intf
        return ipsec_dict

    def get_ipsec_table(self):
        dpt('Start to get ipsec vpn table')
        table_name = 'IPsec VPN Table'
        sub_name = ''
        vpn_table = NCTTable(self._devName, table_name, sub_name)
        group_list = self.generic_call_api_resp('show-groups') or []
        meshed_lst = self.generic_call_api_resp('show-vpn-communities-meshed') or []
        star_lst = self.generic_call_api_resp('show-vpn-communities-star') or []
        if not (meshed_lst or star_lst):
            vpn_table.SetStatus(NCTStatus.Failed)
            msg = 'Failed to retrieve IPSec VPN'
            dpt(msg)
            dpt('#====== IPsec VPN ======#\n', 'No vpn-meshed or vpn-star was found')
            # vpn_table.AddLog(msg)
            return False

        # debug
        vpn_content_lst = []
        vpn_content_lst.append('%s#show-groups\n%s' % (self._devName, json.dumps(group_list, indent=2)))
        vpn_content_lst.append('%s#show-vpn-communities-meshed\n%s' % (self._devName, json.dumps(meshed_lst, indent=2)))
        vpn_content_lst.append('%s#show-vpn-communities-star\n%s' % (self._devName, json.dumps(star_lst, indent=2)))

        has_vpn = False
        ipsec_dct = {
            'Interface': [],
            'Crypto Map': [],
            'VRF Name': [],
            'IPsec VPN Local IP': [],
            'IPsec VPN Remote IP': [],
            'Source Traffic IP': [],
            'Source Traffic Mask': [],
            'Destination Traffic IP': [],
            'Destination Traffic Mask': [],
        }
        append_intf = ipsec_dct['Interface'].append
        append_cry_map_tag = ipsec_dct['Crypto Map'].append
        append_vrf_name = ipsec_dct['VRF Name'].append
        append_src_peer_ip = ipsec_dct['IPsec VPN Local IP'].append
        append_dst_peer_ip = ipsec_dct['IPsec VPN Remote IP'].append
        append_src_traffic_ip = ipsec_dct['Source Traffic IP'].append
        append_src_traffic_mask = ipsec_dct['Source Traffic Mask'].append
        append_dst_traffic_ip = ipsec_dct['Destination Traffic IP'].append
        append_dst_traffic_mask = ipsec_dct[
            'Destination Traffic Mask'].append

        ipsec_data = self.build_ipsec_data() or {}
        # ============== #
        #     meshed     #
        # ============== #
        local_dev_lst = []
        objs_lst = \
            [[objs for objs in meshed_res.get('gateways') if objs.get('name')] for meshed_res in meshed_lst
             if isinstance(meshed_res, dict) and meshed_res.get('gateways')]
        objs_lst = objs_lst[0] if objs_lst else []
        name_lst = [objs.get('name') for objs in objs_lst]
        device_matched = False
        for objs in objs_lst:
            if self.check_device_matched(objs):
                device_matched = True
                local_dev_name = objs.get('name')
                local_dev_lst = [local_dev_name]
                if local_dev_name in name_lst:
                    name_lst.remove(local_dev_name)
                break
        if device_matched:
            for vpn_pair in itertools.product(local_dev_lst, name_lst):
                if len(set(vpn_pair)) == 1:
                    continue
                vpn_local_name = vpn_pair[0]
                vpn_peer_name = vpn_pair[1]
                vpn_local_items = ipsec_data.get(vpn_local_name)
                vpn_peer_items = ipsec_data.get(vpn_peer_name)
                if not (vpn_local_items and vpn_peer_items):
                    continue
                vpn_intf = vpn_local_items['vpn_intf']
                vpn_local_ip = vpn_local_items['vpn_address']
                src_tfc = vpn_local_items['traffic_ip']
                vpn_peer_ip = vpn_peer_items['vpn_address']
                dst_tfc = vpn_peer_items['traffic_ip']
                if vpn_local_items and vpn_peer_items:
                    has_vpn = True
                    append_intf(vpn_intf)
                    append_cry_map_tag('Meshed')
                    append_vrf_name('')
                    append_src_peer_ip(vpn_local_ip)
                    append_dst_peer_ip(vpn_peer_ip)
                    append_src_traffic_ip(src_tfc)
                    append_src_traffic_mask('')
                    append_dst_traffic_ip(dst_tfc)
                    append_dst_traffic_mask('')

        # ============== #
        #      star      #
        # ============== #
        # center-gateways
        center_objs_lst = \
            [[objs for objs in star_res.get('center-gateways') if objs.get('name')] for star_res in star_lst
             if isinstance(star_res, dict) and star_res.get('center-gateways')]
        center_objs_lst = center_objs_lst[0] if center_objs_lst else []
        center_name_lst = [objs.get('name') for objs in center_objs_lst]

        # satellite-gateways
        satellite_objs_lst = \
            [[objs for objs in star_res.get('satellite-gateways') if objs.get('name')] for star_res in
             star_lst if isinstance(star_res, dict) and star_res.get('satellite-gateways')]
        satellite_objs_lst = satellite_objs_lst[0] if satellite_objs_lst else []
        satellite_name_lst = [objs.get('name') for objs in satellite_objs_lst]

        device_matched = False
        for objs in center_objs_lst:
            if self.check_device_matched(objs):
                device_matched = True
                center_name_lst = [objs.get('name')]
                break
        if device_matched:
            star_vpn_lst = itertools.product(center_name_lst, satellite_name_lst)
        else:
            for objs in satellite_objs_lst:
                if self.check_device_matched(objs):
                    device_matched = True
                    satellite_name_lst = [objs.get('name')]
                    break
            star_vpn_lst = itertools.product(satellite_name_lst, center_name_lst)

        if device_matched:
            for vpn_pair in star_vpn_lst:
                if len(set(vpn_pair)) == 1:
                    continue
                vpn_local_name = vpn_pair[0]
                vpn_peer_name = vpn_pair[1]
                vpn_local_items = ipsec_data.get(vpn_local_name)
                vpn_peer_items = ipsec_data.get(vpn_peer_name)
                if not (vpn_local_items and vpn_peer_items):
                    continue
                vpn_intf = vpn_local_items['vpn_intf']
                vpn_local_ip = vpn_local_items['vpn_address']
                src_tfc = vpn_local_items['traffic_ip']
                vpn_peer_ip = vpn_peer_items['vpn_address']
                dst_tfc = vpn_peer_items['traffic_ip']
                if vpn_local_items and vpn_peer_items:
                    has_vpn = True
                    append_intf(vpn_intf)
                    append_cry_map_tag('Star')
                    append_vrf_name('')
                    append_src_peer_ip(vpn_local_ip)
                    append_dst_peer_ip(vpn_peer_ip)
                    append_src_traffic_ip(src_tfc)
                    append_src_traffic_mask('')
                    append_dst_traffic_ip(dst_tfc)
                    append_dst_traffic_mask('')

        if has_vpn:  # successful
            vpn_table.SetColumns(
                ['Interface', 'Crypto Map', 'VRF Name', 'IPsec VPN Local IP', 'IPsec VPN Remote IP',
                 'Source Traffic IP', 'Source Traffic Mask', 'Destination Traffic IP',
                 'Destination Traffic Mask'])
            vpn_table.GetColumns().update(ipsec_dct)
            vpn_table.SetKeys(['Interface'])
            vpn_table.SetStatus(NCTStatus.Success)
            msg = 'Retrieve IPsec VPN Table successfully.'
            dpt(msg)
            # vpn_table.AddLog(msg)
        else:  # failed
            vpn_table.SetStatus(NCTStatus.NA)
            msg = 'No IPsec VPN Table found.'
            dpt(msg)
            # vpn_table.AddLog(msg)

        vpn_content = '\r\n'.join(vpn_content_lst)
        if _nct_details:
            dpt('#====== IPsec VPN ======#\n', vpn_content)
        # vpn_table.SetOriginalText(vpn_content)
        return vpn_table.save_to_csv()


def cpr80_generic_api_resp(endpoint, user, password, url, script='', task_id=''):
    ap = APIPlugin(user, password, endpoint)
    result = ap.generic_call_api_resp(url, script, task_id)
    if _use_cache is False:
        ap.logout_session()
    return result


def cpr80_discover_devices(sms, user, password, params):
    dpt('start to discover cpr80 devices')
    try:
        ap = APIPlugin(user, password, sms, params)
        cpr80_data = ap.retrieve_cpr80_data()
        err_msg = ap.err_msg
        if _use_cache is False:
            ap.logout_session()
        return {
            'result': cpr80_data,
            'msg': err_msg,
            'log': json.dumps(ap.discover_results)}
    except Exception as e:
        dpt(e)
        err_msg = str(e) + '\n'
        dpt(traceback.format_exc())
        pass

    return {'result': False, 'msg': err_msg}


def cpr80_get_table(table_type, param):
    username, password, endpoint,name = extract_param(param)
    log = StatLog.getInstance()
    log.taskEntry({'Device name':name,'table':table_type})
        
    ap = APIPlugin(username, password, endpoint, param)
    dev_table = {}
    if table_type == 'policy':
        try:
            dev_table = ap.get_policy_table()
        except Exception as e:
            dpt(e)
            dpt(traceback.format_exc())
    elif table_type == 'ipsec':
        try:
            dev_table = ap.get_ipsec_table()
        except Exception as e:
            dpt(e)
            dpt(traceback.format_exc())
    elif table_type == 'nat':
        try:
            dev_table = ap.get_nat_table()
        except Exception as e:
            dpt(e)
            dpt(traceback.format_exc())
    if _use_cache is False:
        ap.logout_session()

    log.taskExit()
    if dev_table:
        return 200, dev_table if isinstance(dev_table, str) else json.dumps(dev_table)
    else:
        return 400, '{}'


def cpr80_get_policy_table(param):
    return cpr80_get_table('policy', param)


def cpr80_get_ipsec_table(param):
    return cpr80_get_table('ipsec', param)


def cpr80_get_nat_table(param):
    return cpr80_get_table('nat', param)


def extract_param(param):
    if isinstance(param, str):
        param = json.loads(param)
    username = param.get('username')
    password = param.get('password')
    endpoint = param.get('endpoint')
    name = param.get('name')
    apis = param.get('apis')
    if apis:
        for keys in apis.values():
            if not username:
                username = keys.get('username', '')
            if not password:
                password = keys.get('password', '')
            if not endpoint:
                endpoint = keys.get('endpoint')
    return username, password, endpoint,name


def _test(param):
    try:
        username, password, endpoint = extract_param(param)
        dpt('Start to test cpr80 %s' % endpoint)
        test_rtn = {'isFailed': False}
        dpt(('endpoint', endpoint))
        try:
            ap = APIPlugin(username, password, endpoint, param, test=True)
        except Exception:
            dpt(traceback.format_exc())
        result = ap._sid
        err_msg = ap.err_msg
        if _use_cache is False:
            ap.logout_session()
        if not err_msg and result:
            test_rtn['msg'] = ''
            return 200, json.dumps(test_rtn)
        else:
            test_rtn['msg'] = err_msg
            return 400, json.dumps(test_rtn)
    except Exception:
        dpt(traceback.format_exc())


# This function is used to show discover log, not real to check license
def check_license(endpoint, user, password, params):
    dpt('start to check CheckPoint R80 license')
    try:
        ap = APIPlugin(user, password, endpoint, params)
        result = ap.check_license()
        if _use_cache is False:
            ap.logout_session()
        return result

    except Exception as e:
        err_msg = e.message if hasattr(e, 'message') else str(e)
        dpt(e)
        dpt(traceback.format_exc())

        return {'result': False, 'log': err_msg + '\n'}


if __name__ == "__main__":
    param = {
        "apis": {
            "CheckPointR80": {
            "cmds": [
                "NAT Table"
            ],
            "endpoint": "https://10.10.32.157",
            "methods": [
                "cpr80_get_nat_table"
            ],
            "moduleName": "07f797cb-9cc2-47f5-a847-6adf09b6c198",
            "password": "Netbrain1",
            "specId": "07f797cb-9cc2-47f5-a847-6adf09b6c198",
            "username": "admin"
            }
        },
        "dataSourceId": "0e78287d-5ecd-4792-be46-5d5cb5d397ff",
        "devId": "5762d10f-9cc2-4fde-b16c-fbed638d984a",
        "domain_db_name": "CPR80",
        "isAPIRetrieve": True,
        "is_call_script": True,
        "mainType": 1002,
        "mgmtIP": "10.10.32.164",
        "name": "r80_cluster_32.164_fw1",
        "nbPathSchemas": [
            "CheckPointR80.children.device"
        ],
        "nbPathValues": [
            "cfc45961-e369-417d-a84b-6e6ccedca054/5762d10f-9cc2-4fde-b16c-fbed638d984a"
        ],
        "snmpName": "r80_cluster_32.164_fw1",
        "subType": 30080,
        "tenant_db_name": "Tenant1"
    }

    for i in range(0, 32):
        t = threading.Thread(target=cpr80_get_nat_table, args=(param,))
        t.start()

    while True:
        time.sleep(3)