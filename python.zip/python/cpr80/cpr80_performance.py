import uuid
import threading

class Performance:
    def __init__(self):
        self.running = {}
        self.lock = threading.Lock()


    def get_uuid(self):
        return str(uuid.uuid1())

    def get_tid(self):
        return threading.current_thread().ident

    def begin(self):
        uid = get_uuid()
        pass

    def get_tid_record(self, create_if_notexist = False):
        tid = self.get_tid()
        with self.lock:
            if self.running.has_key(tid):
                return self.running.get(tid)
            


    def end(slef):
        slef.output()

    def output(self):
        record = self.get_tid_record()
        pass



class PfRecord:
    def __init__(self):
        pass
